package sistema;

public class Clima {
	
	private String tipoClima;

	public Clima(String tipoClima) {
		super();
		this.tipoClima = tipoClima;
	}

	public String getTipoClima() {
		return tipoClima;
	} 
}
