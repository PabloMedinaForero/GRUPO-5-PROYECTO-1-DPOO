package sistema;

public class Ubicacion {
	private int numeroPlaza;

	public Ubicacion(int numeroPlaza) {
		super();
		this.numeroPlaza = numeroPlaza;
	}

	public int getNumeroPlaza() {
		return numeroPlaza;
	}
}
